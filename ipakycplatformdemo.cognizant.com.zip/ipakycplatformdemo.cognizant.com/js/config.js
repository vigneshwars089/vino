var app = angular.module('App', ['ngMaterial', 'ui.router', 'ui.bootstrap', 'ngc.arrow', 'ngSanitize','md.time.picker']);

app.service('variables', function ($http) {
  this.freqData = [];

    this.loginStatus = false;
  // this.serverPath="http://10.155.142.17:8089/KYC-Services-0.0.1-SNAPSHOT/api/";
    this.serverPath="/KYC-Services-0.0.1-SNAPSHOT/api/";
  // this.serverPath="http://10.155.142.17:8080/api/";
  this.overallData={
    "TotalVolume": 14,
    "PendingVolume":12,
    "PendingProcessData": {
      "DocumentSourcing": 2,
      "ClientOutreach": 4,
      "Approvals":0,
      "Escalations":0,
      "DueDeligence":0,
      "CompleteKYC":0,
      "DocumentExtraction":0,
      "Deactivate":5

    }
  };
this.freqData = function(){
    var arr = [];
  var batchPost = { "batch1_from" : "29/05/2017", "batch1_to" : "04/06/2017", "batch2_from" : "05/06/2017", "batch2_to" : "11/06/2017", "batch3_from" : "12/06/2017", "batch3_to" : "18/06/2017"}
  $http.post("http://10.219.47.16:8088/api/pending-batches-data", batchPost).then(function(result){
    var obj = {};
    var innerObj = {"All":0,"Batch 1":"","Batch 2":"","Batch 3":""};

    var batches = ["Batch 1", "Batch 2", "Batch 3"];
    var keys = ["Document Sourcing","Client Outreach", "Data Extraction","Due Diligence","Escalations","Approvals",  "Deactivate", "Complete KYC"]
    var sum = 0;
    for(i=0;i<keys.length;i++){
      obj = {}; innerObj = {};
      obj.State = keys[i] ;

      for(j=0;j<result.data.PendingProcessBatchesData.length;j++)
      {

        if(result.data.PendingProcessBatchesData[j].BatchNumber==batches[j]){
          innerObj[batches[j]] = result.data.PendingProcessBatchesData[j][keys[i]];
          sum = sum+innerObj[batches[j]];
        }
      }
      innerObj.All =sum;
      obj.freq = innerObj;
      arr.push(obj);
    }
  });
  return arr;
}

$http.get(this.serverPath+"doc-extraction").then(function(result){
  console.log(result.data.DocExtractionDetails);
})
this.dataArr=[
  {"Client Name":"ARROW GLOBAL", "Company Type":"Private limited Company","Domain":"Beverages", "Address":"Belvedere, 12 Booth Street, Manchester, United Kingdom, M2 4AW", "Nature of Business":"64921 - Credit granting by non-deposit taking finance houses and other specialist consumer credit grantors","Incorporated on":"28-Oct-05",
  "Country Name":"United Kingdom of Great Britain and Northern Ireland","Is blocked Country":"NO","Total Asset":"",
  "Given Name":"ARROW GLOBAL","Legal Suffix":"",
  "Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""
  },
  {"Client Name":"FISKE", "Company Type":"Public limited Company","Domain":"Building Construction", "Address":"Salisbury House, London Wall, London, EC2M 5QS", "Nature of Business":"64999 - Financial intermediation not elsewhere classified",
  "Incorporated on":"21-Apr-88","Country Name":"United Kingdom of Great Britain and Northern Ireland","Is blocked Country":"NO","Total Asset":"",
  "Given Name":"FISKE","Legal Suffix":"",
  "Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""
  },
];
this.pdfData = [];
var obj = {};
for(i=0;i<this.dataArr.length;i++){
    obj = {};
    obj['Name'] = this.dataArr[i]['Client Name'];
    obj['fields'] = Object.keys(this.dataArr[i]);
    obj['values'] = Object.values(this.dataArr[i]);
    obj['path'] = './files/'+this.dataArr[i]['Client Name']+'.pdf';
    obj['asset'] = './files/'+this.dataArr[i]['Client Name']+'_asset.pdf';
    this.pdfData.push(obj);
}console.log(this.pdfData);


// $http.get(this.serverPath+"doc-extraction").then(function(result){
//
//  var obj = {};
//   for(i=0;i<result.data.DocExtractionDetails.length;i++){
//       obj = {};
//       obj['Name'] = result.data.DocExtractionDetails[i]['Company Name'];
//       obj['fields'] = Object.keys(result.data.DocExtractionDetails[i]);
//       obj['values'] = Object.values(result.data.DocExtractionDetails[i]);
//       obj['path'] = './files/'+result.data.DocExtractionDetails[i]['Company Name']+'.pdf';
//       obj['asset'] = './files/'+result.data.DocExtractionDetails[i]['Company Name']+'_asset.pdf';
//       this.pdfData.push(obj);
//   }console.log(this.pdfData);
//
// })


// this.dataArr=[{"Client Id":"GER_8946","Client Name":"DEUTSCHE APOTHEKER-UND ARZTEBANK EG","Country":"Germany","Given Name":"DEUTSCHE APOTHEKER-UND","Legal Suffix":"ARZTEBANK EG",
// "Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"SWIZ_7832","Client Name":"E. GUTZWILLER & CIE, BANQUIERS","Country":"Switzerland","Given Name":"E. GUTZWILLER & CIE, ","Legal Suffix":"BANQUIERS","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"GER_8568","Client Name":"Bank Julius Baer Europe AG","Country":"Germany","Given Name":"Bank Julius Baer Europe","Legal Suffix":"AG","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"UK_7832","Client Name":"STANDARD LIFE ASSURANCE COMPANY 2006 (THE)","Country":"UK","Given Name":"STANDARD LIFE ASSURANCE COMPANY 2006 (THE)","Legal Suffix":"Ltd","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"UK_9562","Client Name":"ALLIANZ GLOBAL INVESTORS KAPITALANLAGEGESELLSCHAFT MHB","Country":"UK","Given Name":"Allianz Global Investors ","Legal Suffix":"Gmbh","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"UK_8523","Client Name":"J.M. Finn & Co. Ltd","Country":"UK","Given Name":"J.M. Finn & Co. ","Legal Suffix":"Ltd","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"UK_6589","Client Name":"UBS AG LONDON BRANCH","Country":"UK","Given Name":"UBS AG","Legal Suffix":"LLP","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"CAN_7536","Client Name":"Foresters Asset Management INC","Country":"Canada","Given Name":"Foresters Asset Management","Legal Suffix":"INC","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""},
// {"Client Id":"CAN_5894","Client Name":"Royal Bank of Canada","Country":"Canada","Given Name":"Royal Bank of Canada","Legal Suffix":"LLP","Resolved Root/Client Name":"","Resolved Legal Suffix Name":"","Effective date of Resolved  Root/Client Name and Legal":'',"Reference Source":"","Reference Links":""}];
// this.pdfData=[
//   {
//     'Name':'EFG Private Bank Limited',
//     'fields':['CompanyName','CompanyType','RegisteredOfficeAddress','PhoneNumber','CompanyIncorporatedOn','Incorporated on','Previous Company Name','PreviousCompanyName','BussinessAddress'],
//     'values':['EFG Private Bank Limited','Public limited Company','Leconfield House Curzon Street London W1J 5JB UNITED KINGDOM','44 02078723644','25 November 1988','EFG Private Bank Limited','Leconfield House Curzon Street London W1J 5JB UNITED KINGDOM','EFG Private Bank Limited','Leconfield House Curzon Street London W1J 5JB UNITED KINGDOM'],
//     'path':'./clientfiles/EFG Private Bank Limited.pdf'
//   },
//   {
//     'Name':'Royal Bank of Canada',
//     'fields':['CompanyName','CompanyType','RegisteredOfficeAddress','PhoneNumber','CompanyIncorporatedOn','Incorporated on','Previous Company Name','PreviousCompanyName','BussinessAddress','ShareHolder1 : C F Harrison','ShareHolder2 : S J Cockburn','ShareHolder3 : Mrs C M Short','ShareHolder4 : A R Fiske-Harrison','ShareHolder5 : B A F Harrison','ShareHolder6 : LongSand Limited','ShareHolder7 : Craven Hill Investment Ltd.'],
//     'values':['','','', '','','','','','','','','','','','','',''],
//     'path':'./clientfiles/Charles Stanley & Co Ltd.pdf'
//   },
//   {
//     'Name':'FISKE',
//     'fields':['Company Name','Company Type','Registered Office Address','Phone Number','Incorporated on','Country Of Share Register','Previous Company Name','Bussiness Address'],
//     'values':['FISKE PLC','Public limited Company','Salisbury House, London Wall, London, EC2M 5O5','02074484700','21 April 1988','GB','FISKE & CO LTD','Salisbury House London Wall    London   EC2M 5QS  UNITED KINGDOM'],
//     'ShareHolder':{"ShareHolder1": {
//       "@Name": "C F Harrison",
//       "@OrdinaryShares": "2,334,828",
//       "@Percentage": "27.60"
//     },
//     "ShareHolder2": {
//       "@Name": "S J Cockburn",
//       "@OrdinaryShares": "421,227",
//       "@Percentage": "4.98"
//     },
//     "ShareHolder3": {
//       "@Name": "Mrs C M Short",
//       "@OrdinaryShares": "421,227",
//       "@Percentage": "4.56"
//     },
//     "ShareHolder4": {
//       "@Name": "A R Fiske-Harrison",
//       "@OrdinaryShares": "315,842",
//       "@Percentage": "3.73"
//     },
//     "ShareHolder5": {
//       "@Name": "B A F Harrison",
//       "@OrdinaryShares": "280,000",
//       "@Percentage": "3.31"
//     },
//     "ShareHolder6": {
//       "@Name": "LongSand Limited",
//       "@OrdinaryShares": "2,133,802",
//       "@Percentage": "25.17"
//     },
//     "ShareHolder7": {
//       "@Name": "Craven Hill Investment Ltd.",
//       "@OrdinaryShares": "396,413",
//       "@Percentage": "4.68"
//     }},
//     'path':'./clientfiles/FISKE.pdf'
//   },
//   {
//     'Name':'Wesleyan Assurance Society',
//     'fields':['CompanyName','CompanyType','RegisteredOfficeAddress','PhoneNumber','CompanyIncorporatedOn','Incorporated on','Previous Company Name','PreviousCompanyName','BussinessAddress'],
//     'values':['FISKE PLC','Public limited Company','Salisbury House, London Wall, London, EC2M 5QS','44 02074484700','21 April 1988','FISKE & CO LTD','Salisbury House London Wall    London   EC2M 5QS  UNITED KINGDOM','FISKE & CO LTD','Salisbury House London Wall    London   EC2M 5QS  UNITED KINGDOM'],
//     'path':'./clientfiles/Wesleyan Assurance Society.pdf'
//   }];

});
