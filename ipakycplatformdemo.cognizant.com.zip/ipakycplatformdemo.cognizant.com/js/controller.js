


app.config(function($stateProvider, $urlRouterProvider) {



    // Redirect to default landing page/home page
    $urlRouterProvider.when('', '/login');

    $stateProvider

    // HOME STATES AND NESTED VIEWS ========================================
        .state('login', {
            url: '/login',
            templateUrl: '../views/login.html'
        })
        .state('home', {
            url: '/home',
            templateUrl: '../views/home.html'
        })
        .state('home.mainContent', {
            url: '/mainContent',
            templateUrl: '../views/mainContent.html'
        })
        .state('home.businessProcess', {
            url: '/businessProcess',
            templateUrl: '../views/businessProcess.html'
        })
        .state('home.completedView', {
            url: '/completedView',
            templateUrl: '../views/completedView.html'
        })
        .state('home.automationSetup', {
            url: '/automationSetup',
            templateUrl: '../views/automationSetupPage.html'
        })
        .state('home.userTask', {
            url: '/userTask',
            templateUrl: '../views/userTaskPage.html'
        })
        .state('home.pdfView', {
            url: '/pdfView',
            templateUrl: '../views/pdfView.html'
        })
        .state('errorPage', {
            url: '*path',
            templateUrl: '../views/errorPage.html'
        })
});

app.directive('fileInput', ['$parse', function($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attributes) {
            element.bind('change', function() {
                $parse(attributes.fileInput)
                    .assign(scope, element[0].files)
                scope.$apply()
            });
        }
    };
}]);
app.factory('GetNameService', function($http, $q) {
    var token = "1234";
    var cust = ["Charles Stanley & Co Ltd", "EFG Private Bank Limited", "FISKE", "Wesleyan Assurance Society"];
    return {
        getName: function(str) {

            //         var url = "https://digitalopssolutionscatalogservice.cognizant.com/Solution/auto_nodes/" + str;
            //         return $http.get(url,{headers:  {
            //                 'AuthorizationToken': token
            //               }})
            //             .then(function(response) {
            //               console.log(response);
            //
            //               return response.data;
            //
            //
            // });

            return cust;
        }
    }
});

app.directive('repeatDone', function() {
    return function(scope, element, attrs) {
        element.bind('$destroy', function(event) {
            if (scope.$last) {

                scope.$eval(attrs.repeatDone);
            }
        });
    }
});
app.filter('millisectotime', function() {

    // In the return function, we must pass in a single parameter which will be the data we will work on.
    // We have the ability to support multiple other parameters that can be passed into the filter optionally
    return function(input) {
        function msToHMS(ms) {
            // 1- Convert to seconds:
            var seconds = ms / 1000;
            // 2- Extract hours:
            var hours = parseInt(seconds / 3600); // 3,600 seconds in 1 hour
            seconds = seconds % 3600; // seconds remaining after extracting hours
            // 3- Extract minutes:
            var minutes = parseInt(seconds / 60); // 60 seconds in 1 minute
            // 4- Keep only seconds not extracted to minutes:
            seconds = seconds % 60;
            // console.log(minutes+" min : "+seconds+" seconds!");
            return (minutes + " min : " + Math.round(seconds) + " sec");
        }



        return msToHMS(input);

    }

});
app.controller("homeController", function($scope, $state, $timeout, $window, $mdpTimePicker, $http, GetNameService, variables, $mdDialog, $mdToast) {
    var a = moment(42522);
    $scope.loadBar==true;
    $scope.time = new Date();

    $scope.message = {
        hour: 'Hour is required',
        minute: 'Minute is required',
        meridiem: 'Meridiem is required'
    }
    $scope.username = "";
    $scope.password = "";

    $scope.viewSelector = "Bar Graph";
    angular.element($window).on('storage', function(event) {
        if (event.originalEvent.key === 'isUserLoggedIn') {
            $window.location.reload();
        }
    });
    $scope.loginFunction = function(username, password) {
        if ((username || password) == null)
            $scope.error = "Associate ID or Password is required!!";
        var username = username;
        var pword = password;
        var key = CryptoJS.enc.Utf8.parse('cca2016Cognizant');
        var iv = CryptoJS.enc.Utf8.parse('Cognizant2016cca');
        var encryptedpassword = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(pword), key, {
            keySize: 128 / 8,
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        pword = encryptedpassword.ciphertext.toString(CryptoJS.enc.Base64);

        var userObj = {
            'Password': pword,
            'UserName': username
        };
        //$state.go('home.mainContent');
        $http.post("https://commandcenterservice.cognizant.com/api/UserAccount/Login", userObj)
            .success(function(result) {
                variables.loginStatus = true;
                $state.go('home.mainContent');
                $window.sessionStorage && $window.sessionStorage.setItem('isUserLoggedIn', true);
            }).error(function(err) {

                if (err.EmailAddress == null)
                    $scope.error = "Associate ID or Password Incorrect !!";
                else
                    $state.go('home.mainContent');

            });
    }


    // $http.get(variables.serverPath+"completed-processes-for-month/5").then(function(response){
    //   console.log(response.data);
    //   $scope.completedProcessList=response.data;
    // });

    $scope.updateTable = function(month) {
        var monthArr = ["Jan", "Jan", "Feb", "Mar", "Apr", "May", "June"];
        var monthNum = monthArr.indexOf(month);

        $http.get(variables.serverPath + "completed-processes-for-month/" + monthNum).then(function(response) {
            $scope.completedProcessList = response.data;
            $('#completedDataTable').DataTable().destroy();
            $timeout(function() {
                $('#completedDataTable').DataTable({
                    "ordering": true,
                    "info": false,
                    "searching": true,
                    "lengthChange": false,
                    "pageLength": 5
                });
            }, 10);
        });


    }
    $scope.fileDetails = {};
    $scope.openFileSelect = function(id) {
        angular.element(document.querySelector(id)).click();
    };
    $scope.selectedPdf;

    $scope.fileDetailsSave = function(data) {

        var json = [{
                "Process Name": data['Process Name'],
                "File Name": data["inputFile"][0].name,
                "Date": moment(data["date"]).format("MMM Do YYYY"),
                "Time": moment(data["time"]).format("hh:mm:ss a"),
                "Output Format": data["outputFormat"]
            }]
            // document.execCommand("SaveAs",true,"C:\\My Documents\\Saved Content.html");
            // console.log(json);
            // $(window).keypress(function(e){
            //
            //    if((event.which == 115 && event.ctrlKey) && !(event.which == 19)){
            //        //Ctrl + "+" is pressed, 61 is for =/+ anr 43 is for Numpad + key
            //    }
            //
            // });
            // var event = new Event('click');
            // window.dispatchEvent(event.which == 115 && event.ctrlKey)
        alasql('SELECT * INTO XLSX("kyc_platform.xlsx",{headers:true}) FROM ?', [json]);
        // window.open(alasql('SELECT * INTO XLSX("john.xlsx",{headers:true}) FROM ?',[json]));


        $mdToast.show(
            $mdToast.simple()
            .textContent('Saved Successfully')
            .position('bottom right')
            .hideDelay(1000)
        );
        // $state.go('home.businessProcess');

    }
    $scope.pdfChange = function(pdf) {
        $scope.userSelectedPdf = pdf;
    }
    $scope.pdfData=[];
    $http.get("https://ipakycplatformdemo.cognizant.com/KYC-Services-0.0.1-SNAPSHOT/api/doc-extraction").then(function(result){
      console.log(result.data.DocExtractionDetails);
     var obj = {};
      for(i=0;i<result.data.DocExtractionDetails.length;i++){
          obj = {};
          obj['Name'] = result.data.DocExtractionDetails[i]['Company Name'];
          obj['fields'] = Object.keys(result.data.DocExtractionDetails[i]);
          obj['values'] = Object.values(result.data.DocExtractionDetails[i]);
          obj['path'] = './files/'+result.data.DocExtractionDetails[i]['Company Name']+'.pdf';
          obj['asset'] = './files/'+result.data.DocExtractionDetails[i]['Company Name']+'_asset.pdf';
          console.log(obj);
          $scope.pdfData.push(obj)
      }
      console.log($scope.pdfData);

    })
    // $scope.pdfData = variables.pdfData;
    $scope.sampleSave = function(userSelectedPdf) {
        $mdToast.show(
            $mdToast.simple()
            .textContent('Saved Successfully')
            .position('bottom left')
            .hideDelay(1000)
        );
    }
    $scope.assetClick = function(assetPdf){
      $scope.userSelectedPdf.asset = $scope.userSelectedPdf.path;
      $scope.userSelectedPdf.path = assetPdf;
    }
    $scope.date = null;
    $scope.dataArr = variables.dataArr;
    $scope.searchDisp = false;
    $scope.changestate = function() {
        $state.go('home.mainContent');
    }
    $scope.test = "  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    $scope.days = [1];



    $scope.isDisabled = false;


    $scope.noCache = false;
    $scope.selectedItem = undefined;
    $scope.searchText = "";
    $scope.text = '';
    $scope.searchDisp = false;
    $scope.tileData = [];
    $scope.changestate = function() {
        $state.go('home.mainContent');
    }
    $scope.serverData = {};
    //     var appendArr= [
    //       {"ACT_ID":0, "ACT_NAME_":"Client name and other details entry for KYC onboarding","ACT_Count":1},
    //       {"ACT_ID":1, "ACT_NAME_":"Document Sourcing", "ACT_Count":0},
    // {"ACT_ID":2, "ACT_NAME_":"Client Outreach", "ACT_Count":0},
    // {"ACT_ID":3, "ACT_NAME_":"Data Extraction", "ACT_Count":0},
    // {"ACT_ID":4, "ACT_NAME_":"Due Deligence", "ACT_Count":0},
    // {"ACT_ID":5, "ACT_NAME_":"Escalations", "ACT_Count":0},
    // {"ACT_ID":6, "ACT_NAME_":"Approvals", "ACT_Count":0},
    // {"ACT_ID":7, "ACT_NAME_":"Deactivate", "ACT_Count":5},
    // {"ACT_ID":8, "ACT_NAME_":"Complete KYC", "ACT_Count":0}
    // ];

    $http.get(variables.serverPath + "current-view-data").then(function(result) {

        $scope.serverData = result.data;
        $scope.tileData = $scope.serverData.PendingProcessData;

    })
    var keys = ["DocumentSourcing", "ClientOutreach", "DocumentExtraction", "DueDeligence", "Escalations", "Approvals", "Deactivate", "CompleteKYC"]
    $scope.days = [1];
    $scope.callChart = function() {
        var totalVol = [];
        var percent = [];

        for (j = 0; j < $scope.tileData.length; j++) {

            totalVol[j] = $scope.tileData[j].ACT_COUNT;

            percent[j] = Math.round(($scope.tileData[j].ACT_COUNT / $scope.serverData.TotalVolume) * 100);
        }

        // console.log(totalVol);console.log(percent);
        var max = Math.max.apply(Math, percent);
        for (j = 0; j < $scope.tileData.length; j++) {
            donutPlus("#cardPlus" + j, percent[j], totalVol[j]);
        }
        for (i = 0; i < $scope.tileData.length; i++) {
            donut("#card" + i, percent[i], totalVol[i], max);
        }
        $scope.loadBar==false;
    }


    $scope.modalPop = function() {
        $('#dialog_confirm_map').modal('show');
        $('.modal-backdrop').appendTo('.bigform-content');
        $('#example').DataTable();
    }
    $scope.callChart1 = function() {
        // var batchPost = { "batch1_from": "05/01/2017", "batch1_to": "05/07/2017", "batch2_from": "05/08/2017", "batch2_to": "05/14/2017", "batch3_from": "05/15/2017", "batch3_to": "05/21/2017" }
        //get batches range dynamically
            var dateObj = {};

            function getRangeFormat(date){
                var today = date;
                var dd = today.getDate();
                var mm = today.getMonth()+1; //January is 0!

                var yyyy = today.getFullYear();
                if(dd<10){
                    dd='0'+dd;
                }
                if(mm<10){
                    mm='0'+mm;
                }
                var today = mm+'/'+dd+'/'+yyyy;
                return today;
            }
            function getMonday(d) {
              d = new Date(d);
              var day = d.getDay(),
              diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
              return new Date(d.setDate(diff));
            }
            var d = new Date();
            var firstDay = getMonday(d);
            var noOfDays = 6;
            var noOfBatches = 3;
            dateObj['batch'+noOfBatches+'_from'] = getRangeFormat(firstDay);
            d.setDate(firstDay.getDate()+noOfDays);
            dateObj['batch'+noOfBatches+'_to'] = getRangeFormat(d);
            // dateArr.push(dateObj);

            for(i=noOfBatches-1;i>=noOfBatches-2;i--){

                          firstDay.setDate(firstDay.getDate()-1)
                          dateObj['batch'+i+'_to'] = getRangeFormat(firstDay);
                          firstDay.setDate(firstDay.getDate()-noOfDays);
                          dateObj['batch'+i+'_from'] = getRangeFormat(firstDay);
                          // dateArr.push(obj);
                        }

        var batchPost = { "batch1_from" : "05/29/2017", "batch1_to" : "06/04/2017", "batch2_from" : "06/05/2017", "batch2_to" : "06/11/2017", "batch3_from" : "06/12/2017", "batch3_to" : "06/18/2017"}
        var batchPost = dateObj;
        $http.post(variables.serverPath + "pending-batches-data", batchPost).then(function(result) {

            var obj = {};
            var innerObj = { "All": 0, "Work Package 1": "", "Work Package 2": "", "Work Package 3": "" };
            var arr = [];
            var batches = ["Batch 1", "Batch 2", "Batch 3"];
            var workPackages = ["Work Package 1", "Work Package 2", "Work Package 3"];
            var keys = ["Document Sourcing", "Client Outreach", "Data Extraction", "Due Diligence", "Escalations", "Approvals", "Deactivate", "Complete KYC"]
            var sum = 0;
            for (i = 0; i < keys.length; i++) {
                obj = {};
                innerObj = {};
                obj.State = keys[i];
                sum = 0;
                // for (j = 0; j < workPackages.length; j++) {
                //
                //
                //     if (result.data.PendingProcessBatchesData[0].BatchNumber == batches[j]) {
                //         innerObj[workPackages[j]] = result.data.PendingProcessBatchesData[0][keys[i]];
                //         sum = sum + innerObj[workPackages[j]];
                //     }
                // }console.log(innerObj);
                for (m = 0; m < result.data.PendingProcessBatchesData.length; m++){
                    for (j = 0; j < workPackages.length; j++) {
                  if (result.data.PendingProcessBatchesData[m].BatchNumber == batches[j]) {
                      innerObj[workPackages[j]] = result.data.PendingProcessBatchesData[m][keys[i]];
                      sum = sum + innerObj[workPackages[j]];
                  }
                }




                }
                innerObj.All = sum;
                obj.freq = innerObj;
                arr.push(obj);
            }

            batchChart('#dashboard', arr, batchPost, $scope.serverData.TotalVolume, result.data.TotalProcessBatchesData);
        });
        // lineChart();
    }
    $scope.horizontalBarChart = function() {
        // horizontalBarChart();
    }

    $scope.openModal = function(stage) {
        $scope.stage = stage;
        $('#dialog_confirm_map').modal('show');
        $('.modal-backdrop').appendTo('.bigform-content');
        $scope.buildTable();

    }




    $scope.openModalGraph = function(clientId) {
        $http.get(variables.serverPath + "completed-activities-for-process/" + clientId).then(function(response) {
            $scope.timeGraphData = response.data;

            horizontalBarChart($scope.timeGraphData.CompletedActivitiesList);
            timeGraphFun($scope.timeGraphData.CompletedActivitiesList);
        });
        // $scope.stage = stage;
        // $scope.days = days;
        $('#dialog_graph_map').modal('show');
        $('.modal-backdrop').appendTo('.graphContent');
        // timegraph2();
    }
    $scope.openModalPdf = function(stage) {
        $('#dialog_pdf_map').modal('show');
        $('.modal-backdrop').appendTo('.pdfContent');
    }
    $scope.timegraph = function() {
        // timeGraphFun();
        // lineChart();
        // console.log($scope.days);
        // barChart();
        // timegraph2();
    }


    $scope.refresh = function() {
        $window.location.reload();
    }

    $scope.$watch(function() {
        return $state.$current.name
    }, function(newVal, oldVal) {
        var isUserLoggedIn = $window.sessionStorage.getItem('isUserLoggedIn');
        if (!isUserLoggedIn) {
            $state.go('login');
        } else {
            if (newVal == "home.completedView") {
                $scope.searchDisp = true;
            } else {
                $scope.searchDisp = false;
            }
            if (newVal == "home.mainContent" || newVal == "home.completedView") {
                $scope.showNavBtn = true;
            } else {
                $scope.showNavBtn = false;
            }
        }
    })
    $scope.redrawArrow = function() {
        var evt = window.document.createEvent('UIEvents');
        evt.initUIEvent('resize', true, true, window, 0);
        setTimeout(function() {
            window.dispatchEvent(evt);

        }, 100);
    }

    $scope.dataTable = function() {
      $http.get(variables.serverPath + "completed-view-data").then(function(result) {

          // completedChart(result.data.CompletedProcessData);
          completedChart(result.data.CompletedProcessData, result.data.CompletedProcessDataWeekwise);

      console.log($scope.maxMonthGet);

        $http.get(variables.serverPath + "completed-processes-for-month/" + $scope.maxMonthGet).then(function(response) {

            $scope.completedProcessList = response.data;
            console.log($scope.completedProcessList);
            $timeout(function() {
                $('#completedDataTable').DataTable({
                    "ordering": true,
                    "info": false,
                    "searching": true,
                    "lengthChange": false,
                    "pageLength": 5
                });
            }, 10);
        });

        // completedChart();
})
    }

    $scope.navBarClick = function(id) {
        $(".nav li").removeClass("active");
        $("#" + id).addClass("active");
        if (id == "dashboardNav")
            $("#current").addClass("active");
        if (id == "current" || id == "completed")
            $("#dashboardNav").addClass("active");
    }
    $scope.logoutfun = function() {
        variables.loginStatus = false;
        var confirm = $mdDialog.confirm()
            .title('Are you Sure?')
            .textContent('You wish to log out??')
            .ok('YES')
            .cancel('NO');

        $mdDialog.show(confirm).then(function() {
            $window.sessionStorage.removeItem('isUserLoggedIn');
            $state.go("login");
        }, function() {
            $state.go("home.mainContent");
        });
    };



    $scope.clearRow = function() {
        $scope.trigger(null)
    }
    $scope.trigger = function(data) {
        if (!$scope.$$phase) {
            $scope.$apply(function() {
                $scope.selectedRow = data;
              });
        } else {
            $scope.selectedRow = data;
        }
    }
    $scope.selectedItemChange = function(item) {
        if ($scope.selectedItem)
            $scope.text = $scope.selectedItem;
    }
    $scope.searchTextChange = function(str) {

        return GetNameService.getName(str);
    }
    $scope.specificSearch = function(text) {
        $scope.openModalGraph(text);
    }




    $scope.open1 = function() {
        $scope.popup1.opened = true;
    };
    // $scope.time;
    $scope.updateRow = function(selectedRow) {
        $scope.dataArr[$scope.index] = { "Client Id": selectedRow[0], "Client Name": selectedRow[1], "Country": selectedRow[2], "Given Name": selectedRow[3], "Legal Suffix": selectedRow[4], "Resolved Legal Suffix name": selectedRow[5], "Effective date of Resolved Root/Client Name and Legal": selectedRow[6], "Reference Source": selectedRow[7], "Reference Links": selectedRow[8] };
        $scope.buildTable();

        $mdToast.show(
            $mdToast.simple()
            .textContent('Saved Successfully')
            .position('bottom right')
            .hideDelay(1000)
        );
    };

    $scope.buildTable = function() {
        var html = '<table id="example" class="display table-striped table-bordered" cellspacing="0" width="100%"><thead style="background-color:#164a61;color:white"><tr><th>Client Name</th><th>Company Type</th><th>Country</th><th>Given Name</th><th>Legal Suffix</th><th>Resolved Root/Client name</th><th>Resolved Legal Suffix name </th><th>Effective date of Resolved  Root/Client Name and Legal   </th><th>Reference Source  </th><th>Reference Links  </th></tr></thead><tbody>';
        // var html='<table id="example" class="display" cellspacing="0" width="100%"><thead><tr><th>Client ID</th><th>Client Name</th><th>RFirm Type</th></tr></thead><tbody>';
        for (var i = 0; i < $scope.dataArr.length; i++) {
            var row = $scope.dataArr[i];
            html += "<tr  style='cursor:pointer'><td>" + row['Client Name'] + "</td><td>" + row['Company Type'] + "</td><td>" + row['Country Name'] + "</td><td>" + row['Given Name'] + "</td><td>" + row['Legal Suffix'] + "</td><td>" + row['Resolved Root/Client Name'] + "</td><td>" + row['Resolved Legal Suffix Name'] + "</td><td>" + row['Effective date of Resolved  Root/Client Name and Legal'] + "</td><td>" + row['Reference Source'] +
                "</td><td>" + row['Reference Links'] + "</td></tr>";
            // html+="<tr  style='cursor:pointer'><td>"+row['Client ID']+"</td><td>"+row['Client Name']+"</td><td>"+row['Firm Type']+"</td></tr>";
        }
        html += "</tbody></table>"

        var insertData = $("#inserTableData").html(html);
        var events = $('#events');
        var table = $('#example').DataTable({
            "aaSorting": [],
            "columnDefs": [{
                "targets": [3, 4, 5, 6, 7, 8, 9],
                "visible": false,
                "searchable": false
            }],
            // "displayStart": $scope.index,
            "pageLength": 11,
            select: {
                style: 'single'
            }
        });
        table
            .on('select', function(e, dt, type, indexes) {
                var rowData = table.rows(indexes).data().toArray();
                $scope.index = indexes[0]
                $scope.trigger(rowData[0])

                events.prepend('<div><b>' + type + ' selection</b> - ' + JSON.stringify(rowData) + '</div>');
            })
            .on('deselect', function(e, dt, type, indexes) {
                // console.log("deselect");

                var rowData = table.rows(indexes).data().toArray();
                events.prepend('<div><b>' + type + ' <i>de</i>selection</b> - ' + JSON.stringify(rowData) + '</div>');
            })
        if ($scope.index == undefined) {
            $scope.index = 0;
        };

        var pageNum = ($scope.index + 1) / 11;

        table.page(Math.floor(pageNum)).draw(false)
        table.row(':eq(' + $scope.index + ')').select();
    }


    $scope.today = function() {
        $scope.dt = new Date();
    };

    $scope.today();

    $scope.clear = function() {
        $scope.dt = null;
    };

    $scope.inlineOptions = {
        customClass: getDayClass,
        minDate: new Date(),
        showWeeks: true
    };

    $scope.dateOptions = {
        dateDisabled: disabled,
        formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: new Date(),
        startingDay: 1
    };

    // Disable weekend selection
    function disabled(data) {
        var date = data.date,
            mode = data.mode;
        return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
    }

    $scope.toggleMin = function() {
        $scope.inlineOptions.minDate = $scope.inlineOptions.minDate ? null : new Date();
        $scope.dateOptions.minDate = $scope.inlineOptions.minDate;
    };

    $scope.toggleMin();



    $scope.open2 = function() {
        $scope.popup2.opened = true;
    };

    $scope.setDate = function(year, month, day) {
        $scope.dt = new Date(year, month, day);
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];
    $scope.altInputFormats = ['M!/d!/yyyy'];

    $scope.popup1 = {
        opened: false
    };

    $scope.popup2 = {
        opened: false
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date();
    afterTomorrow.setDate(tomorrow.getDate() + 1);
    $scope.events = [{
        date: tomorrow,
        status: 'full'
    }, {
        date: afterTomorrow,
        status: 'partially'
    }];

    function getDayClass(data) {
        var date = data.date,
            mode = data.mode;
        if (mode === 'day') {
            var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

            for (var i = 0; i < $scope.events.length; i++) {
                var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                if (dayToCheck === currentDay) {
                    return $scope.events[i].status;
                }
            }
        }

        return '';
    }


    $http.get(variables.serverPath + "completed-view-data").then(function(result) {

    });
});
