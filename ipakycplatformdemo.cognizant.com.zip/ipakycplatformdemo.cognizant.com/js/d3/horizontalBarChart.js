function horizontalBarChart(data){

// data = [
//     {label:"Document Sourcing", start:"2012-03-01",end:"2012-03-03",days:"3" },
//     {label:"Client outreach", start:"2012-03-03",end:"2012-03-06",days:"3"},
//     {label:"Doc Extraction & Validation", start:"2012-03-06",end:"2012-03-10",days:"1"},
//     {label:"Due Deligence", start:"2012-03-12",end:"2012-03-15",days:"3"},
//     {label:"Escalations", start:"2012-03-015",end:"2012-03-18",days:"2"},
//     {label:"Approvals", start:"2012-03-18",end:"2012-03-23",days:"3"},
//     {label:"Deactivate", start:"2012-03-24",end:"2012-03-26",days:"7"},
//     {label:"Complete KYC", start:"2012-03-26",end:"2012-03-30",days:"9"},
// ]
var a=document.getElementById("horizontalBarChart").innerHTML="";
console.log(a);

    var axisMargin = 20,
            margin = 10,
            valueMargin = 4,
            width = 900,
            height =300,
            barHeight = 25,
            barPadding = 7,
            data, bar, svg, maxDate,scale, xAxis, labelWidth = 0;
// console.log(d3.select('#horizontalBarChart').style('width'));
    max= maxDate = d3.max(data, function(d) { return d['END TIME']; });
    minDate=d3.min(data, function(d) { return d['START TIME']; });
    console.log("max is "+ new Date(max));
    console.log("min is "+new Date(minDate));
    svg = d3.select('#horizontalBarChart')
            .append("svg")
            .attr("width", width)
            .attr("height", height);
            // .attr("padding-bottom","5%");


    bar = svg.selectAll("g")
            .data(data)
            .enter()
            .append("g");

    bar.attr("class", "bar")
            .attr("cx",0)
            .attr("transform", function(d, i) {
                return "translate(" + margin + "," + (i * (barHeight + barPadding) + barPadding) + ")";
            });

    bar.append("text")
            .attr("class", "horzontalLabel")
            .attr("y", barHeight / 2)
            .attr("dy", ".35em") //vertical align middle
            .text(function(d){
                return d['ACTIVITY NAME'];
            }).each(function() {
        labelWidth = 180;
    });
    // var scale =
    var x = d3.time.scale()
        .domain([new Date(minDate), d3.time.day.offset(new Date(max),0.0003)])
        .rangeRound([0, width - margin - labelWidth]);
        // console.log(this.getBBox().width);

     xAxis = d3.svg.axis()
        .scale(x)
        .orient('bottom')
        // .ticks(d3.time.days, 3)
        .innerTickSize(-height)
        .tickFormat(d3.time.format("%d/%m/%y %H:%M:%S"))
        // .tickSize(0)
        .tickPadding(8);


    bar.append("rect")
            .attr("transform", function(d){
                return "translate("+(labelWidth+x(new Date(d['START TIME'])))+",0)";
            })
            .attr("height", barHeight)
            .attr("width", function(d){
                  return x(new Date(d['END TIME']))-x(new Date(d['START TIME']));
            });

            // var tickArr = x.ticks();
            // var sd= new Date("2012-03-15");
            // console.log(sd);
            // var tickDistance = x(tickArr[0]) - x(sd);
            // console.log(tickDistance);
    bar.append("text")
            .attr("class", "value")
            .attr("y", barHeight / 2)
            .attr("dx", -valueMargin + labelWidth) //margin right
            .attr("dy", ".35em") //vertical align middle
            .attr("text-anchor", "end")
            .attr("fill",function(d){
              console.log();
                if (msToHMS(d['END TIME']-d['START TIME'])==0){
                  return "red"
                }else{
                  return "black"
                }
            })
            .text(function(d){
                return (msToHMS(d['END TIME']-d['START TIME']));
            })
            .attr("x", function(d){
                var width = this.getBBox().width;
                return Math.max(width + valueMargin, x(new Date(d['END TIME'])));
            });
            var div = d3.select("#CVmodalContentHeight").append("div").attr("id", "toolTip");
    bar
            .on("mousemove", function(d){
                div.style("left", d3.event.pageX-80+"px");
                div.style("top", d3.event.pageY-25+"px");
                div.style("display", "inline-block");
                div.attr("class","customTooltip");
                div.html("<b>"+(d['ACTIVITY NAME'])+"</b><br><hr>"+"<span> Start: <b>"+(moment(d['START TIME']).format('MMMM Do YYYY, h:mm:ss a'))+"</b> </span><br><span> End: <b>"+(moment(d['END TIME']).format('MMMM Do YYYY, h:mm:ss a'))+"</b></span>");
            });
    bar
            .on("mouseout", function(d){

                div.style("display", "none");
            });
            function msToHMS( ms ) {
                // 1- Convert to seconds:
                var seconds = ms / 1000;
                // 2- Extract hours:
                var hours = parseInt( seconds / 3600 ); // 3,600 seconds in 1 hour
                seconds = seconds % 3600; // seconds remaining after extracting hours
                // 3- Extract minutes:
                var minutes = parseInt( seconds / 60 ); // 60 seconds in 1 minute
                // 4- Keep only seconds not extracted to minutes:
                seconds = seconds % 60;
                // console.log(minutes+" min : "+seconds+" seconds!");
                if(minutes>0){
                  return ( minutes+" m "+(Math.round(seconds)+" s"))
                } else {
                  return (Math.round(seconds)+" s" );
                }

            }
    svg.insert("g",":first-child")
            .attr("class", "axisHorizontal")
            .attr("transform", "translate(" + (margin + labelWidth) + ","+ (height - axisMargin - margin)+")")
            .call(xAxis)
            .selectAll("text")
            .style("text-anchor", "end")
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
            .attr("transform", function(d) {
                return "rotate(-55)"
                })
          .attr("padding-bottom","8%");
}
