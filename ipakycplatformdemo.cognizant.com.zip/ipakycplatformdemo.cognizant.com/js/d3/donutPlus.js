function donutPlus(card, percentage, totVol){
  var chart = $("#donutPlus"),
      aspect = chart.width() / chart.height(),
      container = chart.parent();
      $(window).on("resize", function() {
      var targetWidth = container.width();
      chart.attr("width", targetWidth);
      chart.attr("height", Math.round(targetWidth / aspect));
  }).trigger("resize");
  var p = Math.floor((Math.random() * 200) + 1);
  var width = 150,
      height = 160,
      radius = Math.min(width, height) / 2;
      var arc = d3.svg.arc()
          .outerRadius(radius - 50)
          .innerRadius(radius - 20);
          var svg = d3.select(card).append("svg")
              .attr("width", width)
              .attr("height", height)
              .attr("id","donutPlus")
              .attr('viewBox','0 0 140 150')
            .append("g")
              .attr("transform", "translate(75," + height / 1.78 + ")");
              var color = d3.scale.ordinal()
                  .range(["#d86426", "#8ccbe7", "#80d498"]);



var pie = d3.layout.pie()
    .sort(null)
    .value(function(d) { return d.total; });


    // var fields = [{'name':"Completed",'color':'#d86426'},
    //               {'name':"Delayed",'color':'#8ccbe7'},
    //               {'name':"Progress",'color':'#80d498'}
    //             ];

    var fields = [{'name':"Manual Queue",'color':'#d86426'},
                  {'name':"Robot Queue",'color':'#8ccbe7'}
                ];
var data = [];
var dataObj = {};
// var objArray = ["Delayed", "Completed", "Progress"];
var objArray = ["Manual Queue", "Robo Queue"];
// var objArrayTot = [100, 100, 100];
var objArrayTot = [24, 76];
var percent = ["24%","76%"];
var sum = 0;
dataObj.status = '';
dataObj.total = 0;
for(i=0;i<objArray.length;i++){
  dataObj = {};
  dataObj.status = objArray[i];
  dataObj.total = objArrayTot[i];
  dataObj.percent = percent[i];
  data.push(dataObj);
  sum += dataObj.total;

}

var legend = svg.selectAll(".legend")
  .data(fields)
  .enter().append("g")
    .attr("class", "legend")
    .attr("transform", function(d, i) {
      if(i==0)i=-1;
      if(i==1)i=-70;
      return "translate(" + (i)  + ",-90)"; });

// draw legend colored rectangles
legend.append("rect")
    .attr("x", 0)
    .attr("y", 10)
    .attr("width", 10)
    .attr("height", 10)
    .attr("class","rect")
    .style("fill", function(d){ return d.color;});

// draw legend text
legend.append("text")
    .attr("x", 14)
    .attr("y", 14)
    .attr("dy", ".35em")
    .style("text-anchor", "start")
    .text(function(d) { return d.name })
    .attr("font-size",9)
d3.select("#legend_svg").attr("position","relative");


  var g = svg.selectAll(".arc")
      .data(pie(data))
    .enter().append("g")
      .attr("class", "arc");

  g.append("path")
      .attr("d", arc)
      .style("fill", function(d) { return color(d.data.status); })
      .append("svg:title")
        .text(function(d, i) {return d.data.percent; });

  g.append("text")
      .attr("transform", function(d) { return "translate(" + arc.centroid(d) + ")"; })
      .attr("dy", ".35em")

      .text(function(d) { return d.data.percent; });


function type(d) {
  d.total = +d.total;
  return d;
}

svg.append("text")
        .attr("transform", function(d){if(percentage.toString().length==2) return "translate(-18," + height /40 + ")"; return "translate(-10," + height /40 + ")"})
        .attr("font-size", 25)
        .text(function(d) { return percentage; });
svg.append("text")
        .attr("transform", function(d){if(percentage.toString().length==2) return "translate(9," + height /40 + ")"; return "translate(5," + height /40 + ")"})
        .attr("font-size", 13)
        .text(function(d) { return "%"; });
d3.select(card).append("text")
          .attr("transform", "translate(70,80)")
          .attr("font-size", 30)
            .text(function(d,i) { return "Pending Volume: "+totVol; });

}
