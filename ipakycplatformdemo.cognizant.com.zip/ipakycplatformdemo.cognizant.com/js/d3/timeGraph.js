function timeGraphFun(timeData){
  console.log(timeData);
  var dataArray = [];
  var obj = {x:"",y:"",startTime:"",endTime:"",label:""};

      for (var i = 0; i < timeData.length; i++) {
        obj = {};
        obj.x = timeData[i]['START TIME'];
        obj.y = Math.round(timeData[i]['DURATION_']/1000);
        obj.label = timeData[i]['ACTIVITY NAME']
        obj.startTime = timeData[i]['START TIME'];
        obj.startTime = timeData[i]['END TIME'];
        dataArray.push(obj);

    }
    // dataArray.push(obj);
    console.log(dataArray);
  	var chart = new CanvasJS.Chart("timeGraph",
  	{
      theme: "theme1",
      width: 1000,
  		exportEnabled: true,
  		axisY: {
  			includeZero:false,
  			suffix: "s",
        labelFontSize: 12,
  			title: "Completed Seconds",
        titleFontSize:20
  		},
  		axisX: {
        interval: 50,
        intervalType: "hour",
        labelFontSize: 12,
        title: "May 25, 2017",
        titleFontSize:20

  		},    dataPointWidth: 15,
  		data: [
  		{
         markerSize: 15,
      toolTipContent: "<strong style='color:blue'>{xLabel}</strong><br/> <strong> Cumulative :{y} seconds<br/>",
      indexLabelFontSize : 13,
      indexLabelMaxWidth: 60 ,
      color:"steelblue",
  	   type: "splineArea",
			//  dataPoints: [
      //
			// 	{x: new Date(2017,00,02), y:[0, 0, 20, 3], phase:"Document Sourcing"},
			// 	{x: new Date(2017,00,03), y:[3, 0, 20, 5], phase:"Client Outreach"},
      //   {x: new Date(2017,00,04), y:[5, 0, 20, 8], phase:"Due Diligence"},
      //   {x: new Date(2017,00,05), y:[0, 0, 20, 0], phase:"Escalations"},
      //   {x: new Date(2017,00,06), y:[0, 0, 20, 0], phase:"Approvals"},
      //   {x: new Date(2017,00,07), y:[8, 0, 20, 20], phase:"Deactivate"}
			// ]
      dataPoints: [
      {x: new Date(2017, 0, 1), y: 3,  individual:3, xLabel:"Document Sourcing", indexLabel: "Document Sourcing", durationStart:"Jan 01", durationEnd:"Jan 03"},
      {x: new Date(2017, 0, 3), y: 5,  individual:3, xLabel:"Client Outreach", indexLabel: "Client Outreach", durationStart:"Jan 03", durationEnd:"Jan 06"},
      {x: new Date(2017, 0, 6), y: 0,  individual:2, xLabel:"Doc Extraction & Validation", indexLabel: "Doc Extraction & Validation",durationStart:"Jan 06", durationEnd:"Jan 08"},
      {x: new Date(2017, 0, 8), y: 8,  individual:4, xLabel:"Due Deligence", indexLabel: "Due Deligence",durationStart:"Jan 08", durationEnd:"Jan 12"},
      {x: new Date(2017, 0, 12), y: 0, individual:2, xLabel:"Escalations", indexLabel: "Escalations",durationStart:"Jan 12", durationEnd:"Jan 14"},
      {x: new Date(2017, 0, 15), y: 0, individual:3, xLabel:"Approvals", indexLabel: "Approvals",durationStart:"Jan 14", durationEnd:"Jan 17"},
      {x: new Date(2017, 0, 19), y: 20, individual:4, xLabel:"Deactivate", indexLabel: "Deactivate",durationStart:"Jan 17", durationEnd:"Jan 21"},
      {x: new Date(2017, 0, 30), y: 0, individual:9, xLabel:"Complete KYC", indexLabel: "Complete KYC",durationStart:"Jan 21", durationEnd:"Jan 30", a:"View Doc", name: "/#/home/pdfView" , }
      ]
    },{
      // type:"candlestick",
      // dataPoints: [
    	// 	{x: new Date(2017,00,01), y:[0, 0, 20, 3], phase:"Document Sourcing"},
			// 	{x: new Date(2017,00,03), y:[3, 0, 20, 5], phase:"Client Outreach"},
      //   {x: new Date(2017,00,06), y:[0, 0, 20, 0], phase:"Data Extraction"},
      //   {x: new Date(2017,00,08), y:[5, 0, 20, 8], phase:"Due Diligence"},
      //   {x: new Date(2017,00,12), y:[0, 0, 20, 0], phase:"Escalations"},
      //   {x: new Date(2017,00,15), y:[0, 0, 20, 0], phase:"Approvals"},
      //   {x: new Date(2017,00,19), y:[8, 0, 20, 20], phase:"Deactivate"},
      //   {x: new Date(2017,00,30), y:[0, 0, 20, 0], phase:"Complete KYC"}
			// ]
      type:"rangeColumn",
      color:"#FF8000",

      toolTipContent: "<strong style='color:blue'>{phase}</strong><br/> <strong> Start: {y[0]} seconds<br/><strong> End: {y[1]} seconds<br/>",
      dataPoints: [
      	{x: new Date(2017,00,01), y:[0, 3], phase:"Document Sourcing"},
      	{x: new Date(2017,00,03), y:[3,  5], phase:"Client Outreach"},
        {x: new Date(2017,00,06), y:[0,  0], phase:"Data Extraction"},
        {x: new Date(2017,00,08), y:[5,  8], phase:"Due Diligence"},
        {x: new Date(2017,00,12), y:[0,  0], phase:"Escalations"},
        {x: new Date(2017,00,15), y:[0,  0], phase:"Approvals"},
        {x: new Date(2017,00,19), y:[8,  20], phase:"Deactivate"},
        {x: new Date(2017,00,30), y:[0,  0], phase:"Complete KYC"}
      ]

    }
  		]
  	});
    // dps = [{label:"hi",y:0},{y:3},{y:6}]
    // chart.addTo("data",{type:"line", yValueFormatString: "0'%'", dataPoints: dps});
    // chart.data[1].set("axisYType", "secondary");
    // chart.axisY[0].set("maximum", 1);
    // chart.axisY2[0].set("maximum", 100);
  	chart.render();

}
