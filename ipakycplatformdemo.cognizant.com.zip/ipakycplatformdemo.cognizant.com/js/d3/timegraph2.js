function timegraph2(timeData) {

  var dataArray = [];
  var obj = {x:"",y:"",startTime:"",endTime:"",label:""};

//   for (var i = 0; i < timeData.length; i++) {
//     obj = {};
//     obj.x = timeData[i]['START TIME'];
//     obj.y = Math.round(timeData[i]['DURATION_']/1000);
//     obj.label = timeData[i]['ACTIVITY NAME']
//     obj.startTime = timeData[i]['START TIME'];
//     obj.startTime = timeData[i]['END TIME'];
//     dataArray.push(obj);
//
// }console.log(dataArray);

    var chart = new CanvasJS.Chart("timeGraph",
    {
      width: 1000,
      zoomEnabled: true,
      theme: "theme4",

      animationEnabled: true,
      axisX:{
                  interval: 500,
                  intervalType: "hour",
                valueFormatString: "hh:mm",
                labelFontSize: 12
              },
      axisY:{
        title: "Seconds",
        includeZero: true,
        labelAngle:0,
        labelFontSize: 12
      },

      data: [
      {
        type: "splineArea",
        bevelEnabled: true,
        indexLabelPlacement: "inside",
        toolTipContent: "<strong style='color:blue'>{label}</strong><br/> <strong>Start Time</strong>: {startTime}<br/> <strong>End Time</strong>: {endTime}<br/><strong>Current</strong>: {y} seconds<br/> <strong>Cumulative</strong>: {y} Days<br/> <a id='timegraph_a_tag' href = {name}>{a}</a>",
        indexLabelMaxWidth: 64,
        indexLabelFontSize: 11,
        indexLabelPlacement: "inside",
        indexLabelWrap: true,


        // //lineThickness: 3,
      //   type: "splineArea",
			// color: "rgba(83, 223, 128, .6)",
        // dataPoints: [
        // {y: 3, a:" ", label: "Document Sourcing", indexLabel: "3", durationStart:"Jan 01", durationEnd:"Jan 03"},
        // {y: 3,  label: "Client Outreach", indexLabel: "3", durationStart:"Jan 03", durationEnd:"Jan 06"},
        // {y: 2,  label: "Doc Extraction & Validation", indexLabel: "2",durationStart:"Jan 06", durationEnd:"Jan 08"},
        // {y: 4,  label: "Due Deligence", indexLabel: "4",durationStart:"Jan 08", durationEnd:"Jan 12"},
        // {y: 2,  label: "Escalations", indexLabel: "2",durationStart:"Jan 12", durationEnd:"Jan 14"},
        // {y: 3,  label: "Approvals", indexLabel: "3",durationStart:"Jan 14", durationEnd:"Jan 17"},
        // {y: 4, label: "Deactivate", indexLabel: "4",durationStart:"Jan 17", durationEnd:"Jan 21"},
        // {y: 9,  label: "Complete KYC", indexLabel: "9",durationStart:"Jan 21", durationEnd:"Jan 30", a:"View Doc", name: "/#/home/pdfView" , }
        // ]
        // dataPoints: [
        // {x: new Date(2017, 0, 1), y: 3,  individual:3, xLabel:"Document Sourcing", indexLabel: "Document Sourcing", durationStart:"Jan 01", durationEnd:"Jan 03"},
        // {x: new Date(2017, 0, 3), y: 6,  individual:3, xLabel:"Client Outreach", indexLabel: "Client Outreach", durationStart:"Jan 03", durationEnd:"Jan 06"},
        // {x: new Date(2017, 0, 6), y: 8,  individual:2, xLabel:"Doc Extraction & Validation", indexLabel: "Doc Extraction & Validation",durationStart:"Jan 06", durationEnd:"Jan 08"},
        // {x: new Date(2017, 0, 8), y: 12,  individual:4, xLabel:"Due Deligence", indexLabel: "Due Deligence",durationStart:"Jan 08", durationEnd:"Jan 12"},
        // {x: new Date(2017, 0, 12), y: 14, individual:2, xLabel:"Escalations", indexLabel: "Escalations",durationStart:"Jan 12", durationEnd:"Jan 14"},
        // {x: new Date(2017, 0, 15), y: 17, individual:3, xLabel:"Approvals", indexLabel: "Approvals",durationStart:"Jan 14", durationEnd:"Jan 17"},
        // {x: new Date(2017, 0, 19), y: 21, individual:4, xLabel:"Deactivate", indexLabel: "Deactivate",durationStart:"Jan 17", durationEnd:"Jan 21"},
        // {x: new Date(2017, 0, 30), y: 30, individual:9, xLabel:"Complete KYC", indexLabel: "Complete KYC",durationStart:"Jan 21", durationEnd:"Jan 30", a:"View Doc", name: "/#/home/pdfView" , }
        // ]

      }


      ]

    });
chart.options.data[0].dataPoints = dataArray;
chart.render();
// document.getElementsByTagName("canvas")[0].attributes.width.value=1000;
// document.getElementsByTagName("canvas")[1].attributes.width.value=1000;
// $("canvas")[0].attributes.width.value="800"
// $("canvas")[1].attributes.width.value="800"
// console.log($("canvas"));
// $( "canvas" ).trigger( "click" );
}
