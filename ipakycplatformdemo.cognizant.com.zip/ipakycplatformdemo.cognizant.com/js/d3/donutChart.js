function donut(card, percent, totVol, max){
  // document.getElementById('#card1').style.color = "red";
  var chart = $("#donut"),
      aspect = chart.width() / chart.height(),
      container = chart.parent();
      $(window).on("resize", function() {
      var targetWidth = container.width();
      chart.attr("width", targetWidth);
      chart.attr("height", Math.round(targetWidth / aspect));
  }).trigger("resize");


if(percent==max){
  var svgContainer = d3.select(card).append("svg")
                                      // .attr("id","donut")
                                      .attr("width", 150)
                                      .attr('viewBox','0 0 140 150')
                                      .attr("height", 200);

  //Draw the Circle
  var circle = svgContainer.append("circle")
                           .attr("cx", 70)
                          .attr("cy", 80)
                         .attr("r", 50)
                         .attr("fill","steelblue");
                         svgContainer.append("circle")
                          .attr("cx", 70)
                          .attr("cy", 80)
                          .attr("r", 37)
                          .style("fill", "white");

     svgContainer.append("text")
               .attr("transform", function(d){if(percent.toString().length==3)return "translate(45,80)";return "translate(55,80)";})

               .attr("fill", "black")
               .text(function(d,i) { return percent; })
               .style("font-size",25);

     svgContainer.append("text")
               .attr("transform", function(d){ if(percent.toString().length==2)return "translate(82,80)";
               if(percent.toString().length==3)return "translate(85,80)"; return "translate(72,80)"})
              .style("font-size",14)
               .attr("fill", "black")
               .text(function(d) { return "%"; });

     svgContainer.append("text")
               .attr("transform", "translate(50,100)")
              .style("font-size",10)
               .attr("fill", "black")
               .text(function(d) { return "Pending"; });
d3.select(card).append("text")
         .attr("transform", "translate(70,80)")

           .text(function(d,i) { return "Pending Volume: "+totVol; });

// d3.select(card).append("div").attr("class","md-ink-bar")
}else{
  if(percent==0){
    var svgContainer = d3.select(card).append("svg")
      // .attr("id","donut")
                                        .attr("width", 150)
                                          .attr('viewBox','0 0 140 150')
                                        .attr("height", 200);

    //Draw the Circle
    var circle = svgContainer.append("circle")
                             .attr("cx", 70)
                             .attr("cy", 80)
                             .attr("r", 50)
                             .attr("fill","#40515c")
                            //  .style("stroke-dasharray", ("10,3"))
                            //  .style("stroke", "#b00")
                             .style("stroke-width", 2);

                 svgContainer.append("text")
                            .attr("transform", "translate(55,80)")
                            .attr("font-size", 30)
                            .attr("fill", "white")
                            .text(function(d,i) { return percent; });
                  svgContainer.append("text")
                            .attr("transform", "translate(72,80)")
                           .style("font-size",16)
                            .attr("fill", "white")
                            .text(function(d) { return "%"; });
                 svgContainer.append("text")
                            .attr("transform", "translate(50,100)")
                            .attr("font-size", 10)
                            .attr("fill", "lightblue")
                            .text(function(d) { return "Pending"; });
                 d3.select(card).append("text")
                            .attr("transform", "translate(70,80)")
                            .attr("font-size", 30)
                              .text(function(d,i) { return "Pending Volume: "+totVol; });
        }else{


   var svgContainer = d3.select(card).append("svg")
                                      // .attr("id","donut")
                                      .attr("width", 150)
                                      .attr("height", 200)
                                      .attr('viewBox','0 0 140 150')


   //Draw the Circle
   var circle = svgContainer.append("circle")
                            .attr("cx", 70)
                            .attr("cy", 80)
                            .attr("r", 50)
                            .attr("fill","#40515c");

                svgContainer.append("text")
                           .attr("transform", function(d){ if(percent.toString().length==2)return "translate(50,80)"; return "translate(55,80)"})
                           .attr("font-size", 30)
                           .attr("fill", "white")
                            .text(function(d,i) { return percent; });
                  svgContainer.append("text")
                            .attr("transform", function(d){ if(percent.toString().length==2)return "translate(82,80)"; return "translate(72,80)"})
                           .style("font-size",16)
                            .attr("fill", "white")
                            .text(function(d) { return "%"; });
                svgContainer.append("text")
                           .attr("transform", "translate(50,100)")
                           .attr("font-size", 10)
                           .attr("fill", "lightblue")
                            .text(function(d) { return "Pending"; });
                d3.select(card).append("text")
                          .attr("transform", "translate(70,80)")
                          .attr("font-size", 30)
                            .text(function(d,i) { return "Pending Volume: "+totVol; });
          }
        }

}
